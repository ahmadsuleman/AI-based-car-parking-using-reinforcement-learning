using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using System.IO; // Add this at the top with other imports


public class Agent_Script : Agent
{   
    //private RCC_CarControllerV3 RCCInstance = new RCC_CarControllerV3();

    //[SerializeField] private Transform vehicle;
    
	//private RCC_Settings RCCSettings;
    

    public RCC_CarControllerV3 carController;
    
    [SerializeField] private Transform GoalTransform;
    [SerializeField] private Transform milestone;
    [SerializeField] public float current_speed;

    
    [SerializeField] private Material loseMaterial;
    [SerializeField] private Material winMaterial;
    [SerializeField] private MeshRenderer floorRenderMaterial;
    
   
	private float dist_front_cntr;
    private float dist_front_right;
    private float dist_front_left;

    private float dist_back_cntr;
    private float dist_back_right;
    private float dist_back_left;
    private float dist_right;
    private float dist_left;
    private int count_steps;
    private float internal_reward = 0f;

    private float covered_distance = 0f;
    //private double[] obs_returns; 
    private float offset = 2.0f;
    private bool start_reward;
    private bool destination_resched = false;
    private float ray_length = 35.0f;
    private List<string> positionLog = new List<string>();
    private string filePath;
    private string filePath1;
    private float totalReward = 0f;
    private Vector3 lastpose_ = Vector3.zero;
    private int success_count = 0;
    private int fail_count = 0; 
    #region RCC Settings Instance

	private RCC_Settings RCCSettingsInstance;
	private RCC_Settings RCCSettings {
		get {
			if (RCCSettingsInstance == null) {
				RCCSettingsInstance = RCC_Settings.Instance;
				return RCCSettingsInstance;
			}
			return RCCSettingsInstance;
		}
	}

	#endregion

    // Start is called before the first frame update
    void Start()
    {
        
        carController = GetComponent<RCC_CarControllerV3>();
        internal_reward = 0f;
        covered_distance = 0f;
        start_reward = false;
        filePath = Path.Combine(Application.dataPath, "AgentPositionLog1.csv");
        filePath1 = Path.Combine(Application.dataPath, "AgentPositionLog_final.csv");
        positionLog.Add("Time,distance");
        //positionLog.Add("Time,X,Y,Z,Reward, Success, Collision");
        
    }
    public override void CollectObservations(VectorSensor sensor)
    {
        Vector3 rayPosition = new Vector3(transform.position.x, 1, transform.position.z);
        Vector3 leftRayRotation = Quaternion.AngleAxis(-25, transform.up) * transform.forward;
        Vector3 rightRayRotation = Quaternion.AngleAxis(25, transform.up) * transform.forward;
        Ray rayCenter = new Ray(rayPosition, transform.forward);
        Ray rayLeft = new Ray(rayPosition, leftRayRotation);
        Ray rayRight = new Ray(rayPosition, rightRayRotation);
       // Debug.DrawRay(rayCenter.origin, rayCenter.direction * 8);
       // Debug.DrawRay(rayLeft.origin, rayLeft.direction * 8);
       // Debug.DrawRay(rayRight.origin, rayRight.direction * 8);
        RaycastHit hit1;
        RaycastHit hit2;
        RaycastHit hit3;
        dist_front_cntr = 0;
        dist_front_right = 0;
        dist_front_left = 0;
        if (Physics.Raycast(rayCenter,out hit1,ray_length)){
            dist_front_cntr = hit1.distance - offset;
        }
        if (Physics.Raycast(rayLeft,out hit2,ray_length)){
            dist_front_left = hit2.distance- offset;
        } 
        if (Physics.Raycast(rayRight,out hit3,ray_length)){
           dist_front_right  = hit3.distance- offset;
        }

        Vector3 leftBack = Quaternion.AngleAxis(20, transform.up) * transform.forward;
        Ray rayLeftBack = new Ray(rayPosition, leftBack);
        Vector3 Back = Quaternion.AngleAxis(0, transform.up) * transform.forward;
        Ray rayBack = new Ray(rayPosition, Back);
        Vector3 rightBack = Quaternion.AngleAxis(-20, transform.up) * transform.forward;
        Ray rayRightBack = new Ray(rayPosition, rightBack);

        RaycastHit hit4;
        RaycastHit hit5;
        RaycastHit hit6;
        dist_back_cntr = 0;
        dist_back_right = 0;
        dist_back_left = 0;
        if (Physics.Raycast(rayCenter,out hit4,ray_length)){
            dist_back_cntr = hit4.distance - offset;
        }
        if (Physics.Raycast(rayLeft,out hit5,ray_length)){
            dist_back_left = hit5.distance- offset;
        } 
        if (Physics.Raycast(rayRight,out hit6,ray_length)){
           dist_back_right  = hit6.distance- offset;
        }
        //Debug.DrawRay(rayRightBack.origin, rayRightBack.direction * -8);
       // Debug.DrawRay(rayLeftBack.origin, rayLeftBack.direction * -8);
       // Debug.DrawRay(rayBack.origin, rayBack.direction * -8);
        

        Vector3 rightRight = Quaternion.AngleAxis(90, transform.up) * transform.forward;
        Ray rayRightRight = new Ray(rayPosition, rightRight);
        Vector3 leftLeft = Quaternion.AngleAxis(-90, transform.up) * transform.forward;
        Ray rayLeftLeft = new Ray(rayPosition, leftLeft );

        RaycastHit hit7;
        RaycastHit hit8;
        dist_right = 0;
        dist_left = 0;
        if (Physics.Raycast(rayRightRight,out hit7, ray_length)){
            dist_right= hit7.distance - offset;
        }
        if (Physics.Raycast(rayLeftLeft,out hit8,ray_length)){
            dist_left  = hit8.distance- offset;
        } 



        //Debug.DrawRay(rayRightRight.origin, rayRightRight.direction * 8);
        //Debug.DrawRay(rayLeftLeft.origin, rayLeftLeft.direction * 8);
        //dist_left, dist_right, dist_front_cntr, dist_front_right, dist_front_left, 
        //dist_back_cntr, dist_back_right, dist_back_left
        sensor.AddObservation(dist_front_cntr);
        sensor.AddObservation(dist_front_left);
        sensor.AddObservation(dist_front_right);
        sensor.AddObservation(dist_back_cntr);
        sensor.AddObservation(dist_back_right);
        sensor.AddObservation(dist_back_left);
        sensor.AddObservation(dist_right);
        sensor.AddObservation(dist_left);

        Vector3  distance_ = transform.localPosition;
        float  distance_milestone = Vector3.Distance(transform.localPosition, GoalTransform.localPosition);
        sensor.AddObservation(distance_);
        sensor.AddObservation(distance_milestone);
        //Debug.Log("Distance" + dist_front_cntr);
        
        
        
    }
    private void OnApplicationQuit()
    {
      File.WriteAllLines(filePath1, positionLog.ToArray());
      Debug.Log($"Agent position data saved to {filePath1}");
    }


    public override void OnActionReceived(ActionBuffers actionBuffers)
    {

        //int count = StepCount;
        //Debug.Log(count.ToString()); 

        //Debug.Log(actionBuffers.ContinuousActions[0]);
        //Debug.Log(actionBuffers.ContinuousActions[1]);
        carController.gasInput = current_speed; //actionBuffers.ContinuousActions[0];// 
        /*
        if (actionBuffers.ContinuousActions[1] >= 0.5f){
            carController.brakeInput = 1f;
        }
        else{
            carController.brakeInput = 0.0f;
        }
        
        //carController.brakeInput = actionBuffers.ContinuousActions[1];
        //carController.handbrakeInput = actionBuffers.ContinuousActions[2];
        */
        carController.steerInput = actionBuffers.ContinuousActions[0];
        /*
        if (actionBuffers.ContinuousActions[3] >= 0.5f){
            carController.boostInput= 1f;
        }
        else{
           carController.boostInput = 0.0f;
        }
        */
        //Debug.Log( "Break Input" + carController.brakeInput.ToString() +  "handBrak Input" +  carController.handbrakeInput.ToString()+ "Steer Input" + carController.steerInput.ToString()+ "Boost Input" + carController.boostInput.ToString());
        //Debug.Log("brakeInput       " + carController.brakeInput.ToString());
        //Debug.Log("handbrakeInput   " + carController.handbrakeInput.ToString());
        //Debug.Log("steerInput       " + carController.steerInput.ToString());
        //Debug.Log("boostInput       " + carController.boostInput.ToString());
        //transform.localPosition += new Vector3(moveX, 0, moveY) * Time.deltaTime * moveSpeed;
        Vector3 pos = transform.position; //localPosition;
        totalReward = 0f;
        float currentTime = Time.time;
        lastpose_ = pos;

        float distance_1 = Vector3.Distance(transform.localPosition, GoalTransform.localPosition);
        float distance_milestone1 = Vector3.Distance(transform.localPosition, milestone.localPosition);
        float reward = -0.10f;//Mathf.Abs(distance_milestone1);//-0.1f;// #Mathf.Abs(distance_1);
                              //float reward12 = -Mathf.Abs(distance_1);
                              // start_reward = true;
        // Milestone Augmentation
        if (start_reward)
        {
            reward = (13 - Mathf.Abs(distance_1)); // (20 - Mathf.Abs(distance_1));//

        }
        // else
        // {
        //     reward = -Mathf.Abs(distance_milestone1);

        // }
        /*
        float limit_negative = 1.5f;
        if ((dist_front_cntr <= limit_negative) || ( dist_front_left <= limit_negative) || ( dist_front_right <= limit_negative) || ( dist_back_cntr <= limit_negative) || ( dist_back_right <= limit_negative) || ( dist_back_left <= limit_negative) || ( dist_right <= limit_negative) || ( dist_left <= limit_negative)){
            reward  -= 0.5f;
        }
        */
        SetReward(reward);
        bool hogaya = false;
        float limit_end = 0.2f;
        if ((dist_front_cntr <= limit_end) || (dist_front_left <= limit_end) || (dist_front_right <= limit_end) || (dist_back_cntr <= limit_end) || (dist_back_right <= limit_end) || (dist_back_left <= limit_end) || (dist_right <= limit_end) || (dist_left <= limit_end))
        {
            SetReward(-100f);
            reward = -100f;
            positionLog.Add($"{currentTime:F2},{distance_1:F3}");
            
            floorRenderMaterial.material = loseMaterial;
            EndEpisode();
            
        }
        //else{
        //    reward = -0.1f;

        //}
        //
        /*
        if ((count%1000 == 1)){
            SetReward();
            Debug.Log("Reward Given --->   " + -Mathf.Abs(distance_) );
            Debug.Log("Episode End   "+ count.ToString());
            EndEpisode();
        }
        
        
        if (Mathf.Abs(distance_) < covered_distance){
            AddReward(0.1f);
            covered_distance = Mathf.Abs(distance_);
            Debug.Log(" distance_ < covered_distance  " + distance_.ToString() + "   "+ covered_distance.ToString());
        }
        else{
            AddReward(-0.1f);
        }
        */
        if (destination_resched)
        {
            SetReward(3000f);
            reward = 3000f;
            floorRenderMaterial.material = winMaterial;
            Debug.Log("Goal Achieved");

            //positionLog.Add($"{currentTime:F2},{pos.x:F3},{pos.y:F3},{pos.z:F3},50.0");

            totalReward += 25f;

            positionLog.Add($"{currentTime:F2},{distance_1:F3}");
            EndEpisode();
            
        }
        //totalReward += reward;
        // positionLog.Add($"{currentTime:F2},{pos.x:F3},{pos.y:F3},{pos.z:F3}, {totalReward:F3}");

        //positionLog.Add($"{currentTime:F2},{pos.x:F3},{pos.y:F3},{pos.z:F3}");
        // if (destination_resched || hogaya){
        //     EndEpisode();
        // }

        //positionLog.Add($"{currentTime:F2},{pos.x:F3},{pos.y:F3},{pos.z:F3}, {reward:F3}");
        //if (destination_resched || hogaya)
        // {
        //     Debug.Log("Data Logged");
        //     int success = destination_resched ? 1 : 0;
        //     int collision = hogaya ? 1 : 0;
        //     // Log once at terminal state (before reset)
        //     //positionLog.Add($"{currentTime:F2},{pos.x:F3},{pos.y:F3},{pos.z:F3}, {reward12:F3}, success: {success}, collision: {collision}");    
        //     File.WriteAllLines(filePath, positionLog.ToArray());
        //     Debug.Log($"Agent position data saved to {filePath}");
            
        // }
        Debug.Log("Reward --> " +reward.ToString());
        Debug.Log("Goal and Agent  --> " +  distance_1.ToString());
        Debug.Log("Agent and Milestone --> " + distance_milestone1.ToString());
        
        // else
        // {
        //     // Log intermediate rewards only
        //     //Debug.Log("Data Logged");

        // }



    }
    public override void OnEpisodeBegin()
    {
        transform.localPosition = new Vector3(16.67f, 0.8f,3.16f);
        
        transform.eulerAngles = new Vector3(0, -90, 0);
        internal_reward = 0f;
        covered_distance = 100f;
        start_reward = false;
        
        destination_resched = false;
    }
    private void OnTriggerEnter(Collider other){
        
       if (other.TryGetComponent<milestone>(out milestone Milestone)){
    
            //SetReward(+20f);
            start_reward = true;
           // Debug.Log("Goal Actieved");
            //EndEpisode();
        }
       if (other.TryGetComponent<destination>(out destination Destination)){
            destination_resched= true;
            
        }
        /*
        if ((other.TryGetComponent<walls>(out walls Walls))){
            SetReward(-10f);
            Debug.Log("Episode End");
          //  floorRenderMaterial.material = loseMaterial;
            EndEpisode();
        }
        if ( (other.TryGetComponent<cars>(out cars Cars))){
            SetReward(-9f);
            //Debug.Log("Episode End");
          //  floorRenderMaterial.material = loseMaterial;
            EndEpisode();
        }
        */
        
    }
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
        //continuousActions[0] = Input.GetAxis(RCCSettings.verticalInput);
        continuousActions[0] = Input.GetAxis(RCCSettings.horizontalInput); //Mathf.Clamp01(-Input.GetAxis(RCCSettings.verticalInput));
        //continuousActions[1] =Input.GetKey(RCCSettings.handbrakeKB) ? 1f : 0f;
        //continuousActions[2] =Input.GetAxis(RCCSettings.horizontalInput);
        //Debug.Log("Action 0   "+ continuousActions[0].ToString());
        //Debug.Log("Gas Input        " + carController.gasInput.ToString());
        //Debug.Log("brakeInput       " + carController.brakeInput.ToString());
        //Debug.Log("handbrakeInput   " + carController.handbrakeInput.ToString());
        //Debug.Log("steerInput       " + carController.steerInput.ToString());
        
    }

    // Update is called once per frame
   
}