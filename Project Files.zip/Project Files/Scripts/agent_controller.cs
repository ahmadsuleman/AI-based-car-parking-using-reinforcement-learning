using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

public class agent_controller : Agent
{
    [SerializeField] private Transform GoalTransform;
    [SerializeField] private Material loseMaterial;
    [SerializeField] private Material winMaterial;
    [SerializeField] private MeshRenderer floorRenderMaterial;
        // Start is called before the first frame update
    public override void OnActionReceived(ActionBuffers actionBuffers)
    {   
        float moveSpeed = 10f;
        //Debug.Log(actionBuffers.ContinuousActions[0]);
        //Debug.Log(actionBuffers.ContinuousActions[1]);
        float moveX = actionBuffers.ContinuousActions[0];
        float moveY = actionBuffers.ContinuousActions[1];
        transform.localPosition += new Vector3(moveX, 0, moveY) * Time.deltaTime * moveSpeed;
       
        
    }
    public override void OnEpisodeBegin()
    {
        transform.localPosition = new Vector3(Random.Range(-10f, 10f), 3,Random.Range(-10f, 10f));
        GoalTransform.localPosition = new Vector3(Random.Range(-10f, 10f), 3,Random.Range(-10f, 10f));
    }
    public override void CollectObservations(VectorSensor sensor)
    {
        
       sensor.AddObservation(transform.localPosition);
       sensor.AddObservation(GoalTransform.localPosition);
        
    }
    public override void Heuristic(in ActionBuffers actionsOut)
    {
        ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
        continuousActions[0] = Input.GetAxis("Horizontal");
        continuousActions[1] = Input.GetAxis("Vertical");
    }
    private void OnTriggerEnter(Collider other){
        if (other.TryGetComponent<destination>(out destination Destination)){
            SetReward(+100f);
            
        //    floorRenderMaterial.material = winMaterial;
            EndEpisode();
        }
        if (other.TryGetComponent<walls>(out walls Walls)){
            SetReward(-1f);
          //  floorRenderMaterial.material = loseMaterial;
            EndEpisode();
        }
        
    }
    
    
    
}





