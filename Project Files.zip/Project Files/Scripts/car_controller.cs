using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class car_controller : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 rayPosition = new Vector3(transform.position.x, 1, transform.position.z);
        Vector3 leftRayRotation = Quaternion.AngleAxis(-15, transform.up) * transform.forward;
        Vector3 rightRayRotation = Quaternion.AngleAxis(15, transform.up) * transform.forward;
        Ray rayCenter = new Ray(rayPosition, transform.forward);
        Ray rayLeft = new Ray(rayPosition, leftRayRotation);
        Ray rayRight = new Ray(rayPosition, rightRayRotation);
        Debug.DrawRay(rayCenter.origin, rayCenter.direction * 8);
        Debug.DrawRay(rayLeft.origin, rayLeft.direction * 8);
        Debug.DrawRay(rayRight.origin, rayRight.direction * 8);

        Vector3 leftBack = Quaternion.AngleAxis(20, transform.up) * transform.forward;
        Ray rayLeftBack = new Ray(rayPosition, leftBack);
        Debug.DrawRay(rayLeftBack.origin, rayLeftBack.direction * -8);

        Vector3 rightBack = Quaternion.AngleAxis(-20, transform.up) * transform.forward;
        Ray rayRightBack = new Ray(rayPosition, rightBack);
        Debug.DrawRay(rayRightBack.origin, rayRightBack.direction * -8);
        
        Vector3 Back = Quaternion.AngleAxis(0, transform.up) * transform.forward;
        Ray rayBack = new Ray(rayPosition, Back);
        Debug.DrawRay(rayBack.origin, rayBack.direction * -8);
        
        Vector3 rightRight = Quaternion.AngleAxis(90, transform.up) * transform.forward;
        Ray rayRightRight = new Ray(rayPosition, rightRight);
        Debug.DrawRay(rayRightRight.origin, rayRightRight.direction * 8);

        Vector3 rightRight45 = Quaternion.AngleAxis(45, transform.up) * transform.forward;
        Ray rayRightRight45 = new Ray(rayPosition, rightRight45);
        Debug.DrawRay(rayRightRight45.origin, rayRightRight45.direction * 8);
        
        Vector3 rightRight135 = Quaternion.AngleAxis(135, transform.up) * transform.forward;
        Ray rayRightRight135 = new Ray(rayPosition, rightRight135 );
        Debug.DrawRay(rayRightRight135.origin, rayRightRight135.direction * 8);

        Vector3 leftLeft45 = Quaternion.AngleAxis(-45, transform.up) * transform.forward;
        Ray rayLeftLeft45 = new Ray(rayPosition, leftLeft45 );
        Debug.DrawRay(rayLeftLeft45 .origin, rayLeftLeft45.direction * 8);

        Vector3 leftLeft = Quaternion.AngleAxis(-90, transform.up) * transform.forward;
        Ray rayLeftLeft = new Ray(rayPosition, leftLeft );
        Debug.DrawRay(rayLeftLeft.origin, rayLeftLeft.direction * 8);

        Vector3 leftRight = Quaternion.AngleAxis(-135, transform.up) * transform.forward;
        Ray rayLeftRight = new Ray(rayPosition, leftRight );
        Debug.DrawRay(rayLeftRight.origin, rayLeftRight.direction * 8);
        
        //Debug.DrawRay(rayLeft.origin, rayLeft.direction * 10);
        //Debug.DrawRay(rayRight.origin, rayRight.direction * 10);

        /*
        Vector3 off_set = new Vector3(0.6f,0.3f, 2.0f);
        Vector3 position = transform.position + off_set;
        Vector3 forward = transform.forward;
        Quaternion spreadAngle_2 = Quaternion.AngleAxis(12, new Vector3(0, 1, 0));
        Vector3 newVector_2 = spreadAngle_2 * forward;
        

        Debug.DrawRay(position, newVector_2*15f, Color.green);
        Debug.DrawRay(position, forward*15f, Color.red);
        Debug.Log("Trans origin " + transform.position);
        Debug.Log("Forward Value " + transform.forward);

        Vector3 off_set_1 = new Vector3(0f,0.3f, 2.0f);
        Vector3 position_1 = transform.position + off_set_1;
        Vector3 forward_1 = transform.forward;

        Debug.DrawRay(position_1, forward_1*15f, Color.blue);
        Debug.Log("Trans origin " + transform.position);
        Debug.Log("Forward Value " + transform.forward);


        Vector3 off_set_2 = new Vector3(-0.6f,0.3f, 2.0f);
        Vector3 position_2 = transform.position + off_set_2;
        Vector3 forward_2 = transform.forward;
        Quaternion spreadAngle_1 = Quaternion.AngleAxis(-12, new Vector3(0, 1, 0));
        Vector3 newVector_1 = spreadAngle_1 * forward_2;
        

        Debug.DrawRay(position_2, newVector_1*15f, Color.green);
        Debug.Log("Trans origin " + transform.position);
        Debug.Log("Forward Value " + transform.forward);

        Vector3 noAngle = transform.forward;
        Quaternion spreadAngle = Quaternion.AngleAxis(-25, new Vector3(0, 1, 0));
        Vector3 newVector = spreadAngle * noAngle;
        Debug.DrawRay(position_2, newVector*15f, Color.black);
        */
        /*Ray ray = Camera.main.ViewportPointToRay(new Vector3 (0.5f, 0.5f, 0));
        Debug.DrawRay(ray.origin, ray.direction * 100);

        RaycastHit hit;

        if (Physics.Raycast(transform.position, -Vector3.up, out hit))
            print("Found an object - distance: " + hit.distance);
        */
    }
    void FixedUpdate()
    {
       
    }
}
