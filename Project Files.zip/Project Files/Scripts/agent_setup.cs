using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;

public class agent_setup : Agent
{
    public override void OnActionReceived(ActionBuffers actions)
    {
       
        //base.OnActionReceived(actions);
   
        //Debug.Log(actions.DiscreteActions[0].ToString());
        //Debug.Log(actions.DiscreteActions[1].ToString());
        Debug.Log(actions.DiscreteActions[0]);
    }
}
